#
import json
import time

set1 = set()  # 所有论文的id集合
set2 = set()  # threeElement的id集合
set3 = set()  # threeElmenet中ref的集合
set4 = set()  # set2 和set3 的 交集
# with open("./allpaper_0", 'r') as r:
#     for line in r.readlines():
#         line_json = json.loads(line)
#         set1.add(line_json["id"])


# with open("./threeElement_0", 'r') as r:
#     for line in r.readlines():
#         line_json = json.loads(line)
#         set2.add(line_json["id"])
#         for ref in line_json["references"]:
#             set3.add(ref)

# print("len(set1) = {}".format(len(set1)) )

# print("len(set2) = {}".format(len(set2)) )

# print("len(set3) = {}".format(len(set3)) )

# inSet1_cnt = 0
# notSet1_cnt = 0
# inSet2_cnt = 0
# notSet2_cnt = 0

# for s in set3:
#     if s in  set1:
#         inSet1_cnt+=1
#     else :
#         notSet1_cnt  +=1
#     if s in set2:
#         inSet2_cnt += 1
#         set4.add(s)
#     else:
#         notSet2_cnt += 1
# print(len(set4))

# print("in set1 : {} - {}".format(inSet1_cnt/(inSet1_cnt+notSet1_cnt) , 1-inSet1_cnt/(inSet1_cnt+notSet1_cnt)))


# print("in set2 : {} - {}".format(inSet2_cnt/(inSet2_cnt+notSet2_cnt) , 1-inSet2_cnt/(inSet2_cnt+notSet2_cnt)))


# # connectedPair = list()  # 格式 [pa, pb] pa 引用了pb
# list4 = list(set4)

# with open("./list4.txt", "w") as w:
#     w.write(json.dumps(list4))

list4 = list()  # 里面存放的是有效的参考文献，所谓有效，就是指包含科技名词。
with open("./list4.txt", "r") as r:
    list4 = json.loads(r.read())

"""
len(set1) = 3442555
len(set2) = 123320
len(set3) = 548631
in set1 : 0.9495289183440235 - 0.05047108165597647
in set2 : 0.08709679183276191 - 0.9129032081672381
"""


paperPair = list()
# with open("./threeElement1_0") as r:
    
#     fileDict = json.loads(r.read())
#     for key ,values in fileDict.items():
#         for v in values: 
#             if v in list4: # 如果参考文献也在目标论文中，增强条件，如果参考文献也是有效文献
#                 paperPair.append([v, key])  # 后面的论文引用前面的论文
# with open("./paperPair.txt", 'w') as w:
#     w.write(json.dumps(paperPair))
print("paperPair ready.")
with open("./paperPair.txt", 'r') as r:
    paperPair = json.loads(r.read())
# remove_cnt = 0
# for p in  paperPair[:]:  # 去除里面的相互引用
#     if [p[1], p[0]] in paperPair : 
#         remove_cnt  += 1
#         print("remove  ", remove_cnt)
#         paperPair.remove(p)
#    # if  paperPair.count(p) > 1 :
#    #     remove_cnt += 1
#    #     print("dulp")
#    #     paperPair.remove(p)

# 这是去除循环引用的代码 使用之后论文之间的连接又少了
# with open("./paperPair_unique.txt", 'w') as w:
#     w.write(json.dumps(paperPair))

# print("sleep")
# time.sleep(300)

# Pa 引用了Pb [[Pb, Pa]]  # 其中pa pb 都是包含技术名词的文献

# startElement = list()  # 没人引用的元素
# for s in line4: 
#     flag = 0
#     for p in paperPair:
#            # 这里有错误，还有可能这篇论文根本就不在paperpair中
#         if s== p[1]:  # 如果这篇论文引用过别人的论文  
#             flag = 1
#             break
#     if flag == 0:
#         startElement.append(s)
# with open('./startElement.txt', 'w') as w:
#     w.write(json.dumps(startElement))

# with open("./startElement.txt", 'r') as r:
#     startElement = json.loads(r.read())

# a2bDict = dict()  # b引用了a  后引用前
# for p in paperPair:
#     if a2bDict.get(p[0], False) == False:  # 字典里还没有这个元素
#         a2bDict[p[0]] = [p[1]]
#     else :
#         a2bDict[p[0]].append(p[1])

# with open('./a2bDict.txt', 'w') as w:
#     w.write(json.dumps(a2bDict))

with open("./a2bDict.txt", 'r') as r:
    a2bDict =  json.loads(r.read())

print("now, traceback...")
result = []  
rec_cnt = 0
file_Cnt = 0
# pass_list = ["1572593068", "2071958655",'2121133177']
def traceback(pList, rec_cnt):
    global result
    global file_Cnt
    # print("rev_cnt = ", rec_cnt)
    if pList[-1] not in a2bDict or rec_cnt >= 20:
        # print(pList)
        # time.sleep(0.5)
        result.append(pList)
        if len(result) % 10000 == 0:
            print("len(result) = ", len(result))
            time.sleep(1)

        if len(result) > 100000:
            with open("./result_" + str(file_Cnt)+".txt", "w") as w:
                w.write(json.dumps(result))
                result = list()
                file_Cnt +=1 
        return 

    for r in a2bDict[pList[-1]]:
        if r in pList:
            print("error dulp.plist = {}, r = {}.".format(pList, r))
            result.append(pList) 
            return 
        pList.append(r)
        # print("add one!!!")
        traceback(pList, rec_cnt+1)
        del(pList[-1])

# traceback(paperPair[0])
for p in paperPair:
    print(p)
    # if p[0] in pass_list:
    #     continue
    traceback(p, 0)
    print('---------------------- once over ----------------------')
    time.sleep(0.1)


print(len(result))

print("now traceback over...")
max_ = 0
for n in result:
    max_ = max(max_, len(n))
print("max = ", max_) 

with open("./result.txt", "w") as w:
    w.write(json.dumps(result))

# start 23:19
"""
for p in paperPair:
    if p[-1] in a2bDict:  # 如果这篇论文还有人参考：
        for r in a2bDict[p[1]]:  # 对于这篇论文后来的每篇论文
            result.append(p.append(r)) # 做选择
            del(p[-1])   # 撤销选择



# with open('./a2bDict.txt', 'r') as r:
#     a2bDict = json.loads(r.read())


# a2bDict 格式{a:[b,c,d,e]}  # b,c,d,e 都要引用了a


result = list()  # [1,2] [1,3] 
# for p in paperPair:
#     if p[0] in startElement:  # 如果这个链接的被引用元素是头元素
#         # print(result)
#         # print("{}  {}".format(p, type(p)))
#         result.append(p)

# with open('./result.txt', 'w') as w:
#     w.write(json.dumps(result))

with open('./result.txt', 'r') as r:
    result = json.loads(r.read())

print(len(result))
print(len(startElement))
print(len(a2bDict))

new = list()
cnt = 0
while(new != result):
    new = list()
    for r in result:
        if r[-1] in a2bDict: # 说明这个技术后面还有人引用
            for a in a2bDict[r[-1]]: # 对于这个技术后面发展出来的每项技术
                new.append(r.append(a))
                del(r[-1])
        else:
            new.append(r)
    print(len(result))
    with open("./tempFile/file_" + str(cnt), 'w') as w:
        w.write(json.dumps(result))
    cnt += 1

print(len(new))
max_ = 0
for n in new:
    max_ = max(max_, len(n))
print(max_) 
"""